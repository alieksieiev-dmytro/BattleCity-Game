using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum StatsTypes
{
    Damage,
    Health,
    Speed,
    Accuracy,
    Range,
    CountOfBullets
}
